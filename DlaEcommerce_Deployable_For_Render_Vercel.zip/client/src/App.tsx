import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import ProductsPage from "@/pages/products-page";
import CartPage from "@/pages/cart-page";
import EWalletPage from "@/pages/ewallet-page";
import OrdersPage from "@/pages/orders-page";
import AdminOrdersPage from "@/pages/admin/orders-page";
import AdminProductsPage from "@/pages/admin/products-page"; // Added import
import AdminBalancePage from "@/pages/admin/balance-page";
import Navbar from "@/components/layout/navbar";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={ProductsPage} />
      <ProtectedRoute path="/cart" component={CartPage} />
      <ProtectedRoute path="/ewallet" component={EWalletPage} />
      <ProtectedRoute path="/orders" component={OrdersPage} />
      <ProtectedRoute path="/admin/orders" component={AdminOrdersPage} />
      <ProtectedRoute path="/admin/products" component={AdminProductsPage} /> {/* Added route */}
      <ProtectedRoute path="/admin/balance" component={AdminBalancePage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="min-h-screen bg-background">
          <Navbar />
          <main className="container mx-auto px-4 py-8">
            <Router />
          </main>
        </div>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;